import { motion, AnimatePresence } from 'motion/react';
import { X, Trash2, Plus, Minus, ShoppingBag } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

const mockCartItems = [
  {
    id: 1,
    name: 'Blue Dream Reserve',
    brand: 'Aura Farms',
    price: 45,
    quantity: 2,
    image: 'bg-gradient-to-tr from-purple-900/40 to-emerald-900/40'
  },
  {
    id: 2,
    name: 'Watermelon Gummies',
    brand: 'Sweet Relief',
    price: 25,
    quantity: 1,
    image: 'bg-gradient-to-tr from-pink-900/40 to-red-900/40'
  }
];

export function CartDrawer({ isOpen, onClose }: CartDrawerProps) {
  const subtotal = mockCartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[80]"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300, mass: 0.8 }}
            className="fixed inset-y-0 right-0 w-full sm:w-[400px] bg-[#050505]/95 backdrop-blur-xl border-l border-white/10 z-[90] flex flex-col shadow-2xl"
          >
            {/* Header */}
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1, type: 'spring', stiffness: 300, damping: 30 }}
              className="p-6 border-b border-white/10 flex items-center justify-between bg-white/[0.02]"
            >
              <div className="flex items-center gap-3">
                <ShoppingBag className="w-5 h-5 text-primary" />
                <h2 className="font-bold text-xl">Your Cart</h2>
                <span className="bg-primary/20 text-primary text-xs font-bold px-2 py-0.5 rounded-full">
                  {mockCartItems.reduce((acc, item) => acc + item.quantity, 0)}
                </span>
              </div>
              <button 
                onClick={onClose}
                className="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center transition-colors text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </motion.div>

            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {mockCartItems.map((item, index) => (
                <motion.div 
                  key={item.id} 
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.15 + index * 0.05, type: 'spring', stiffness: 300, damping: 30 }}
                  className="flex gap-4 group"
                >
                  <div className={`w-20 h-20 rounded-xl ${item.image} border border-white/10 shrink-0 relative overflow-hidden`}>
                     {/* Abstract shape */}
                     <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                       <div className="w-10 h-10 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm" />
                     </div>
                  </div>
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start mb-1">
                        <h3 className="font-medium leading-tight group-hover:text-primary transition-colors line-clamp-1">{item.name}</h3>
                        <button className="text-gray-500 hover:text-red-400 transition-colors shrink-0 ml-2">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-xs text-gray-500">{item.brand}</p>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-3 glass rounded-lg px-2 py-1 border-white/10">
                        <button className="text-gray-400 hover:text-white transition-colors"><Minus className="w-3 h-3" /></button>
                        <span className="text-sm font-medium w-4 text-center">{item.quantity}</span>
                        <button className="text-gray-400 hover:text-white transition-colors"><Plus className="w-3 h-3" /></button>
                      </div>
                      <span className="font-bold">${item.price * item.quantity}</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Footer */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, type: 'spring', stiffness: 300, damping: 30 }}
              className="p-6 border-t border-white/10 bg-black/50"
            >
              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-gray-400 text-sm">
                  <span>Subtotal</span>
                  <span className="text-white">${subtotal}</span>
                </div>
                <div className="flex justify-between text-gray-400 text-sm">
                  <span>Shipping</span>
                  <span>Calculated at checkout</span>
                </div>
                <div className="h-px bg-white/10 my-2" />
                <div className="flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span className="text-primary">${subtotal}</span>
                </div>
              </div>
              <button className="w-full bg-primary hover:bg-emerald-400 text-black font-bold py-4 rounded-xl transition-all hover:scale-[1.02] active:scale-[0.98] shadow-[0_0_20px_rgba(34,197,94,0.2)]">
                Proceed to Checkout
              </button>
            </motion.div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

import { motion } from 'motion/react';
import { ProfileTab } from '../../pages/Profile';
import { 
  LayoutDashboard, 
  Package, 
  Heart, 
  Award, 
  Repeat, 
  MapPin, 
  CreditCard, 
  GraduationCap, 
  Star, 
  Bell, 
  ShieldCheck, 
  Settings, 
  LifeBuoy, 
  LogOut 
} from 'lucide-react';

interface ProfileSidebarProps {
  activeTab: ProfileTab;
  setActiveTab: (tab: ProfileTab) => void;
}

const navGroups = [
  {
    label: 'Overview',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'orders', label: 'Orders', icon: Package },
      { id: 'favorites', label: 'Favorites', icon: Heart },
      { id: 'rewards', label: 'Rewards', icon: Award },
    ]
  },
  {
    label: 'Account',
    items: [
      { id: 'subscriptions', label: 'Subscriptions', icon: Repeat },
      { id: 'addresses', label: 'Addresses', icon: MapPin },
      { id: 'payment', label: 'Payment Methods', icon: CreditCard },
      { id: 'learning', label: 'Learning Progress', icon: GraduationCap },
      { id: 'reviews', label: 'Reviews', icon: Star },
    ]
  },
  {
    label: 'Preferences',
    items: [
      { id: 'notifications', label: 'Notifications', icon: Bell },
      { id: 'security', label: 'Security', icon: ShieldCheck },
      { id: 'settings', label: 'Settings', icon: Settings },
    ]
  }
];

export function ProfileSidebar({ activeTab, setActiveTab }: ProfileSidebarProps) {
  return (
    <div className="space-y-8 sticky top-24">
      {navGroups.map((group, groupIdx) => (
        <div key={group.label}>
          <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-3 px-4">
            {group.label}
          </h3>
          <div className="space-y-1">
            {group.items.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as ProfileTab)}
                className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all relative group ${
                  activeTab === item.id 
                    ? 'text-white font-medium bg-white/10' 
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <item.icon className={`w-5 h-5 transition-colors ${activeTab === item.id ? 'text-primary' : 'group-hover:text-gray-300'}`} />
                <span>{item.label}</span>
                {activeTab === item.id && (
                  <motion.div
                    layoutId="activeSidebarIndicator"
                    className="absolute left-0 w-1 h-6 bg-primary rounded-r-full shadow-[0_0_10px_rgba(34,197,94,0.5)]"
                  />
                )}
              </button>
            ))}
          </div>
        </div>
      ))}

      <div className="pt-4 border-t border-white/10">
        <button
          onClick={() => setActiveTab('support')}
          className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-gray-400 hover:text-white hover:bg-white/5 transition-all"
        >
          <LifeBuoy className="w-5 h-5" />
          <span>Support</span>
        </button>
        <button
          className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-all mt-1"
        >
          <LogOut className="w-5 h-5" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
}

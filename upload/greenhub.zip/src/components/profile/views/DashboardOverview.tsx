import { motion } from 'motion/react';
import { Package, MapPin, Award, Heart, ArrowRight } from 'lucide-react';
import { ProfileTab } from '../../../pages/Profile';

interface DashboardOverviewProps {
  setActiveTab: (tab: ProfileTab) => void;
}

export function DashboardOverview({ setActiveTab }: DashboardOverviewProps) {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end mb-6">
        <div>
          <h2 className="text-2xl font-bold">Welcome Back, John!</h2>
          <p className="text-gray-400">Here's a summary of your account activity.</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Recent Order */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-[2rem] p-6 border border-white/10"
        >
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold flex items-center gap-2">
              <Package className="w-5 h-5 text-primary" /> Active Delivery
            </h3>
            <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-400 text-xs font-bold rounded-full uppercase tracking-wider">
              On The Way
            </span>
          </div>
          
          <div className="bg-black/30 rounded-xl p-4 border border-white/5 mb-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-400 text-sm">Order #GH-0928</span>
              <span className="font-bold">$125.00</span>
            </div>
            <p className="text-sm font-medium">3 Items • Blue Dream Reserve + 2 more</p>
          </div>
          
          <div className="relative pt-4 pb-2">
            <div className="absolute top-6 left-2 right-2 h-1 bg-white/10 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: '75%' }}
                transition={{ duration: 1, delay: 0.5 }}
                className="absolute inset-y-0 left-0 bg-primary shadow-[0_0_10px_rgba(34,197,94,0.5)]" 
              />
            </div>
            <div className="flex justify-between text-xs text-gray-500 font-medium relative z-10 px-1 mt-6">
              <span>Placed</span>
              <span>Preparing</span>
              <span className="text-primary">Driving</span>
              <span>Arrived</span>
            </div>
          </div>
          
          <button 
            onClick={() => setActiveTab('orders')}
            className="w-full mt-6 py-2.5 bg-white/5 hover:bg-white/10 rounded-xl text-sm font-medium transition-colors"
          >
            Track Order Details
          </button>
        </motion.div>

        {/* Rewards Summary */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass rounded-[2rem] p-6 border border-amber-500/20 relative overflow-hidden group"
        >
          <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/10 rounded-full blur-[50px] -z-10 group-hover:scale-110 transition-transform duration-700" />
          
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" /> GreenHub Rewards
            </h3>
            <button onClick={() => setActiveTab('rewards')} className="text-sm text-gray-400 hover:text-white transition-colors">
              View All
            </button>
          </div>
          
          <div className="flex items-end gap-2 mb-6">
            <span className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 to-amber-500">
              1,250
            </span>
            <span className="text-gray-400 font-medium mb-1.5">Points</span>
          </div>
          
          <div className="bg-black/30 rounded-xl p-4 border border-white/5">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-400">Current Tier: Gold</span>
              <span className="font-bold text-amber-400">250 to Platinum</span>
            </div>
            <div className="h-2 bg-white/10 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 w-[80%]" />
            </div>
          </div>
        </motion.div>

        {/* Recently Saved */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass rounded-[2rem] p-6 border border-white/10"
        >
           <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold flex items-center gap-2">
              <Heart className="w-5 h-5 text-red-400" /> Recently Saved
            </h3>
            <button onClick={() => setActiveTab('favorites')} className="text-sm text-gray-400 hover:text-white transition-colors">
              View All
            </button>
          </div>
          
          <div className="space-y-4">
            {[1, 2, 3].map((_, i) => (
              <div key={i} className="flex items-center gap-4 bg-black/30 p-3 rounded-xl border border-white/5 group hover:border-white/10 transition-colors cursor-pointer">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-tr from-purple-900/40 to-emerald-900/40 shrink-0" />
                <div className="flex-1">
                  <h4 className="font-medium text-sm group-hover:text-primary transition-colors">Premium Cannabis Product</h4>
                  <p className="text-xs text-gray-500">Brand Name</p>
                </div>
                <div className="font-bold text-sm">$45</div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Default Address */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass rounded-[2rem] p-6 border border-white/10"
        >
           <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold flex items-center gap-2">
              <MapPin className="w-5 h-5 text-blue-400" /> Default Address
            </h3>
            <button onClick={() => setActiveTab('addresses')} className="text-sm text-gray-400 hover:text-white transition-colors">
              Manage
            </button>
          </div>
          
          <div className="bg-black/30 rounded-xl p-5 border border-white/5 relative overflow-hidden">
            <div className="absolute right-0 bottom-0 opacity-20 pointer-events-none w-32 h-32">
              {/* Fake map pattern */}
              <div className="w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/20 to-transparent blur-sm" />
            </div>
            
            <div className="relative z-10">
              <span className="px-2 py-1 bg-white/10 rounded text-[10px] font-bold uppercase tracking-wider mb-3 inline-block">Home</span>
              <p className="font-bold text-lg mb-1">John Doe</p>
              <p className="text-gray-400 text-sm mb-1">123 Green Avenue, Apt 4B</p>
              <p className="text-gray-400 text-sm mb-4">Los Angeles, CA 90001</p>
              <p className="text-sm font-medium text-gray-300">Instructions: Leave at front door</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

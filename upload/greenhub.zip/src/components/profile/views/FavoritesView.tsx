import { motion } from 'motion/react';
import { ShoppingBag, Star, CheckCircle2 } from 'lucide-react';

const favorites = [
  { id: 1, name: 'Skywalker OG', brand: 'Cosmic Farms', type: 'Indica', thc: '26%', rating: 4.9, price: 50, image: 'bg-gradient-to-tr from-blue-900/40 to-cyan-900/40' },
  { id: 2, name: 'Mango Haze V-Pen', brand: 'Island Botanicals', type: 'Vape', thc: '80%', rating: 4.7, price: 40, image: 'bg-gradient-to-tr from-yellow-800/40 to-orange-700/40' },
  { id: 3, name: 'Cherry Bomb Chocolates', brand: 'Sweet Relief', type: 'Edibles', thc: '50mg', rating: 4.8, price: 30, image: 'bg-gradient-to-tr from-red-900/40 to-pink-900/40' },
  { id: 4, name: 'Northern Lights Live Resin', brand: 'Cloud Extracts', type: 'Concentrates', thc: '88%', rating: 5.0, price: 60, image: 'bg-gradient-to-tr from-indigo-900/40 to-purple-900/40' },
];

export function FavoritesView() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end mb-2">
        <div>
          <h2 className="text-2xl font-bold mb-2">Saved Favorites</h2>
          <p className="text-gray-400">Products you've wishlisted for later.</p>
        </div>
        <button className="text-sm font-medium text-gray-400 hover:text-white transition-colors">
          Clear All
        </button>
      </div>

      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-6">
        {favorites.map((product, i) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
            className="glass glass-hover rounded-2xl overflow-hidden group flex flex-col border border-white/10"
          >
            <div className={`h-40 w-full ${product.image} relative p-4 flex flex-col justify-between border-b border-white/5`}>
              <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors z-10" />
              <button className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center hover:bg-red-500/40 transition-colors">
                <HeartIcon filled />
              </button>
            </div>
            
            <div className="p-5 flex-1 flex flex-col relative z-20 bg-black/40">
              <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                <div className="flex items-center gap-1">
                  <span>{product.brand}</span>
                  <CheckCircle2 className="w-3 h-3 text-primary" />
                </div>
                <div className="flex items-center gap-1">
                  <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                  <span className="text-white font-medium">{product.rating}</span>
                </div>
              </div>
              
              <h3 className="font-semibold text-lg leading-tight mb-2 group-hover:text-primary transition-colors line-clamp-1">{product.name}</h3>
              
              <div className="flex items-center gap-2 mb-4 text-[10px] font-bold uppercase tracking-wider">
                <span className="text-primary">{product.type}</span>
                <span className="w-1 h-1 rounded-full bg-white/20" />
                <span className="text-gray-400">THC {product.thc}</span>
              </div>
              
              <div className="mt-auto pt-4 border-t border-white/10 flex items-center justify-between">
                <span className="text-xl font-bold">${product.price}</span>
                
                <button className="px-4 h-9 rounded-xl bg-white/10 hover:bg-primary hover:text-black border border-white/10 hover:border-transparent text-sm font-bold transition-all flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4" /> Add
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function HeartIcon({ filled }: { filled?: boolean }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="16" 
      height="16" 
      viewBox="0 0 24 24" 
      fill={filled ? "currentColor" : "none"} 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>
    </svg>
  );
}

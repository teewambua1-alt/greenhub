import { motion } from 'motion/react';
import { Package, Clock, MapPin, CheckCircle2, ChevronRight, FileText } from 'lucide-react';

const orders = [
  {
    id: 'GH-0928',
    date: 'Oct 24, 2024',
    status: 'Out for Delivery',
    total: 125.00,
    items: [
      { name: 'Blue Dream Reserve', qty: 2, price: 45 },
      { name: 'Watermelon Gummies', qty: 1, price: 35 }
    ],
    address: '123 Green Ave, Apt 4B'
  },
  {
    id: 'GH-0842',
    date: 'Oct 12, 2024',
    status: 'Delivered',
    total: 85.50,
    items: [
      { name: 'Live Resin Cartridge', qty: 1, price: 55 },
      { name: 'CBD Sleep Drops', qty: 1, price: 30.50 }
    ],
    address: '123 Green Ave, Apt 4B'
  },
  {
    id: 'GH-0715',
    date: 'Sep 28, 2024',
    status: 'Delivered',
    total: 210.00,
    items: [
      { name: 'Granddaddy Purple', qty: 3, price: 40 },
      { name: 'Pineapple Express', qty: 2, price: 45 }
    ],
    address: '123 Green Ave, Apt 4B'
  }
];

export function OrdersView() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Order History</h2>
        <p className="text-gray-400">Track current deliveries and view past purchases.</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10 w-fit">
        <button className="px-6 py-2 bg-white/10 rounded-lg text-sm font-medium text-white">All Orders</button>
        <button className="px-6 py-2 rounded-lg text-sm font-medium text-gray-400 hover:text-white transition-colors">Active</button>
        <button className="px-6 py-2 rounded-lg text-sm font-medium text-gray-400 hover:text-white transition-colors">Cancelled</button>
      </div>

      <div className="space-y-6">
        {orders.map((order, i) => (
          <motion.div
            key={order.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="glass rounded-[2rem] border border-white/10 overflow-hidden"
          >
            {/* Header */}
            <div className="bg-white/5 p-6 border-b border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-6 text-sm">
                <div>
                  <span className="text-gray-500 block mb-1 uppercase tracking-wider text-[10px] font-bold">Order Number</span>
                  <span className="font-bold">{order.id}</span>
                </div>
                <div>
                  <span className="text-gray-500 block mb-1 uppercase tracking-wider text-[10px] font-bold">Date Placed</span>
                  <span className="font-medium text-gray-300">{order.date}</span>
                </div>
                <div>
                  <span className="text-gray-500 block mb-1 uppercase tracking-wider text-[10px] font-bold">Total Amount</span>
                  <span className="font-bold">${order.total.toFixed(2)}</span>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <button className="px-4 py-2 rounded-xl border border-white/10 hover:bg-white/5 transition-colors text-sm font-medium flex items-center gap-2">
                  <FileText className="w-4 h-4" /> Receipt
                </button>
                <button className="px-4 py-2 rounded-xl bg-primary/10 text-primary hover:bg-primary/20 transition-colors text-sm font-bold border border-primary/20">
                  Track Order
                </button>
              </div>
            </div>

            {/* Body */}
            <div className="p-6">
              <div className="flex items-center gap-2 mb-6">
                {order.status === 'Out for Delivery' ? (
                  <div className="flex items-center gap-2 text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-500/20">
                    <Clock className="w-4 h-4" />
                    <span className="text-xs font-bold uppercase tracking-wider">{order.status}</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-gray-400 bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
                    <CheckCircle2 className="w-4 h-4" />
                    <span className="text-xs font-bold uppercase tracking-wider">{order.status}</span>
                  </div>
                )}
                
                {order.status === 'Out for Delivery' && (
                  <span className="text-sm font-medium text-gray-300 ml-2 flex items-center gap-1">
                    Arriving by 4:30 PM <MapPin className="w-4 h-4 ml-1 text-gray-500" />
                  </span>
                )}
              </div>

              <div className="space-y-4">
                {order.items.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between group">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded-xl bg-gradient-to-tr from-gray-800 to-gray-700 border border-white/5 shrink-0" />
                      <div>
                        <h4 className="font-medium group-hover:text-primary transition-colors">{item.name}</h4>
                        <p className="text-sm text-gray-500">Qty: {item.qty}</p>
                      </div>
                    </div>
                    <div className="font-bold">${item.price.toFixed(2)}</div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Footer */}
            <div className="bg-black/30 p-4 border-t border-white/5 flex justify-between items-center">
              <p className="text-xs text-gray-500 flex items-center gap-2">
                <MapPin className="w-3 h-3" /> Delivered to: {order.address}
              </p>
              <button className="text-sm font-medium text-primary hover:text-emerald-400 transition-colors flex items-center gap-1">
                View Details <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

import { motion } from 'motion/react';
import { Award, Gift, Zap, Crown } from 'lucide-react';

export function RewardsView() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-2">GreenHub Rewards</h2>
        <p className="text-gray-400">Earn points on every purchase and unlock exclusive perks.</p>
      </div>

      {/* Hero Banner */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-[2rem] p-8 border border-amber-500/20 relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-amber-500/20 to-transparent rounded-full blur-[40px] -z-10" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-600 to-yellow-400 flex items-center justify-center p-0.5 shadow-[0_0_20px_rgba(251,191,36,0.3)]">
                <div className="w-full h-full bg-black rounded-full flex items-center justify-center">
                  <Award className="w-6 h-6 text-amber-400" />
                </div>
              </div>
              <div>
                <h3 className="font-bold text-xl text-amber-400">Gold Tier</h3>
                <p className="text-sm text-gray-400">Member since Jan 2024</p>
              </div>
            </div>
            
            <div className="flex items-end gap-2 mb-2">
              <span className="text-5xl font-bold text-white">1,250</span>
              <span className="text-gray-400 font-medium mb-1.5 uppercase tracking-wider text-sm">Points Available</span>
            </div>
          </div>
          
          <div className="bg-black/40 rounded-2xl p-6 border border-white/5 md:w-72">
            <div className="flex justify-between text-sm mb-3">
              <span className="text-gray-400">Next Tier: <span className="text-purple-400 font-bold">Platinum</span></span>
              <span className="font-bold">250 pts</span>
            </div>
            <div className="h-2 bg-white/10 rounded-full overflow-hidden mb-4">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: '80%' }}
                transition={{ duration: 1, delay: 0.2 }}
                className="h-full bg-gradient-to-r from-amber-500 to-purple-500" 
              />
            </div>
            <p className="text-xs text-gray-500 leading-relaxed">
              Earn 250 more points to unlock free priority delivery and 15% off all concentrates.
            </p>
          </div>
        </div>
      </motion.div>

      {/* Available Rewards */}
      <div>
        <h3 className="font-bold text-lg mb-4">Redeem Points</h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <RewardCard 
            icon={<Gift className="w-6 h-6 text-emerald-400" />}
            title="$10 Off Coupon"
            cost={500}
            color="from-emerald-500/20"
            available={true}
            delay={0.1}
          />
          <RewardCard 
            icon={<Zap className="w-6 h-6 text-blue-400" />}
            title="Free Express Delivery"
            cost={800}
            color="from-blue-500/20"
            available={true}
            delay={0.2}
          />
          <RewardCard 
            icon={<Crown className="w-6 h-6 text-purple-400" />}
            title="Premium Accessory Box"
            cost={2000}
            color="from-purple-500/20"
            available={false}
            delay={0.3}
          />
        </div>
      </div>
    </div>
  );
}

function RewardCard({ icon, title, cost, color, available, delay }: any) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className={`glass rounded-2xl p-6 border border-white/5 relative overflow-hidden flex flex-col ${!available ? 'opacity-50 grayscale' : 'hover:border-white/10 cursor-pointer'}`}
    >
      <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl ${color} to-transparent rounded-bl-full opacity-20`} />
      
      <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center mb-6 border border-white/10 relative z-10">
        {icon}
      </div>
      
      <h4 className="font-bold mb-1 relative z-10">{title}</h4>
      <p className="text-sm font-medium text-amber-400 mb-6 relative z-10">{cost} Points</p>
      
      <button 
        disabled={!available}
        className={`w-full py-2.5 rounded-xl text-sm font-bold mt-auto relative z-10 transition-colors ${
          available ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-white/5 text-gray-500 cursor-not-allowed'
        }`}
      >
        {available ? 'Redeem Now' : 'Not Enough Points'}
      </button>
    </motion.div>
  );
}

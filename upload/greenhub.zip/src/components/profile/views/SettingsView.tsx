import { motion } from 'motion/react';
import { Settings, User, Bell, Shield, Wallet, Globe } from 'lucide-react';

export function SettingsView() {
  return (
    <div className="space-y-8 max-w-3xl">
      <div>
        <h2 className="text-2xl font-bold mb-2">Account Settings</h2>
        <p className="text-gray-400">Manage your profile preferences and configuration.</p>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-3xl overflow-hidden border border-white/10"
      >
        <div className="p-6 border-b border-white/10 bg-white/[0.02]">
          <h3 className="font-bold flex items-center gap-2">
            <User className="w-5 h-5 text-primary" /> Profile Information
          </h3>
        </div>
        <div className="p-6 space-y-6">
          <div className="grid sm:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-gray-500">First Name</label>
              <input type="text" defaultValue="John" className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary/50 transition-colors" />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-gray-500">Last Name</label>
              <input type="text" defaultValue="Doe" className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary/50 transition-colors" />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-gray-500">Email Address</label>
            <input type="email" defaultValue="john.doe@example.com" className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary/50 transition-colors" />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-gray-500">Phone Number</label>
            <input type="tel" defaultValue="+1 (555) 123-4567" className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary/50 transition-colors" />
          </div>
          <button className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-medium transition-colors border border-white/5">
            Save Changes
          </button>
        </div>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="glass rounded-3xl overflow-hidden border border-white/10"
      >
        <div className="p-6 border-b border-white/10 bg-white/[0.02]">
          <h3 className="font-bold flex items-center gap-2">
            <Bell className="w-5 h-5 text-primary" /> Communication Preferences
          </h3>
        </div>
        <div className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-white mb-1">Order Updates</h4>
              <p className="text-sm text-gray-400">Receive SMS and email notifications about your order status.</p>
            </div>
            <div className="w-12 h-6 bg-primary rounded-full relative cursor-pointer">
              <div className="w-5 h-5 bg-black rounded-full absolute top-0.5 right-0.5 shadow-sm" />
            </div>
          </div>
          <div className="h-px bg-white/5" />
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-white mb-1">Marketing Emails</h4>
              <p className="text-sm text-gray-400">Receive exclusive offers, product news, and educational content.</p>
            </div>
            <div className="w-12 h-6 bg-white/10 rounded-full relative cursor-pointer border border-white/10">
              <div className="w-5 h-5 bg-gray-400 rounded-full absolute top-0.5 left-0.5 shadow-sm" />
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

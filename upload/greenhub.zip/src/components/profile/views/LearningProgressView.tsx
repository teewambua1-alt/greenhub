import { motion } from 'motion/react';
import { BookOpen, Trophy, PlayCircle } from 'lucide-react';

export function LearningProgressView() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-2">Learning Progress</h2>
        <p className="text-gray-400">Track your cannabis education journey and achievements.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-2xl p-6 border border-white/10"
        >
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 border border-primary/20">
            <BookOpen className="w-6 h-6 text-primary" />
          </div>
          <span className="text-3xl font-bold block mb-1">12</span>
          <span className="text-sm text-gray-400">Articles Read</span>
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass rounded-2xl p-6 border border-white/10"
        >
          <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center mb-4 border border-purple-500/20">
            <PlayCircle className="w-6 h-6 text-purple-400" />
          </div>
          <span className="text-3xl font-bold block mb-1">4</span>
          <span className="text-sm text-gray-400">Videos Watched</span>
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass rounded-2xl p-6 border border-white/10"
        >
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center mb-4 border border-amber-500/20">
            <Trophy className="w-6 h-6 text-amber-400" />
          </div>
          <span className="text-3xl font-bold block mb-1">2</span>
          <span className="text-sm text-gray-400">Certificates</span>
        </motion.div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="glass rounded-3xl p-8 border border-white/10 relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-[60px] -z-10" />
        
        <h3 className="font-bold text-lg mb-6">Current Path: Beginner Fundamentals</h3>
        
        <div className="space-y-6">
          <div className="bg-black/40 rounded-xl p-4 border border-white/5 flex items-center gap-4">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-black shrink-0">
               <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
            </div>
            <div>
              <h4 className="font-medium text-white line-through text-gray-500">Cannabis Basics</h4>
            </div>
          </div>
          
          <div className="bg-white/5 rounded-xl p-4 border border-primary/30 flex items-center gap-4 relative overflow-hidden">
            <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary" />
            <div className="w-8 h-8 rounded-full border-2 border-primary text-primary flex items-center justify-center font-bold text-sm shrink-0">
               2
            </div>
            <div className="flex-1">
              <h4 className="font-bold text-white mb-1">Understanding THC</h4>
              <div className="h-1.5 w-full bg-black/50 rounded-full overflow-hidden">
                <div className="h-full bg-primary w-[45%]" />
              </div>
            </div>
            <button className="px-4 py-2 bg-primary text-black font-bold text-xs rounded-lg shrink-0">Continue</button>
          </div>
          
          <div className="bg-black/20 rounded-xl p-4 border border-white/5 flex items-center gap-4 opacity-60">
            <div className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center font-bold text-sm shrink-0">
               3
            </div>
            <div>
              <h4 className="font-medium text-white">Understanding CBD</h4>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

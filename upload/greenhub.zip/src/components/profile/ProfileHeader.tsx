import { motion } from 'motion/react';
import { Award, Package, Heart, MapPin } from 'lucide-react';

export function ProfileHeader() {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative rounded-[2rem] overflow-hidden bg-black border border-white/10 p-8 md:p-10 flex flex-col md:flex-row items-center md:items-start gap-8"
    >
      <div className="absolute inset-0 bg-gradient-to-r from-emerald-900/20 to-black z-0" />
      <div className="absolute right-0 top-0 w-96 h-96 bg-primary/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2" />
      
      <div className="relative z-10 shrink-0">
        <div className="w-32 h-32 rounded-full border-4 border-black shadow-[0_0_0_2px_rgba(255,255,255,0.1)] overflow-hidden relative group">
          <img 
            src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=1000&auto=format&fit=crop" 
            alt="Profile" 
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-xs font-medium cursor-pointer">
            Edit Photo
          </div>
        </div>
      </div>
      
      <div className="relative z-10 flex-1 text-center md:text-left flex flex-col items-center md:items-start">
        <div className="flex flex-col md:flex-row items-center gap-3 mb-2">
          <h1 className="text-3xl font-bold">John Doe</h1>
          <span className="px-3 py-1 bg-gradient-to-r from-amber-500/20 to-yellow-500/20 text-amber-400 border border-amber-500/20 rounded-full text-xs font-bold uppercase tracking-wider flex items-center gap-1">
            <Award className="w-3 h-3" /> Gold Member
          </span>
        </div>
        
        <p className="text-gray-400 mb-6">Member since January 2024 • ID: #GH-84729</p>
        
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 w-full max-w-2xl">
          <div className="glass rounded-xl p-3 border-white/5 flex flex-col items-center md:items-start">
            <div className="flex items-center gap-2 text-gray-400 mb-1">
              <Package className="w-4 h-4 text-primary" />
              <span className="text-xs uppercase tracking-wider">Orders</span>
            </div>
            <span className="text-xl font-bold">24</span>
          </div>
          <div className="glass rounded-xl p-3 border-white/5 flex flex-col items-center md:items-start">
            <div className="flex items-center gap-2 text-gray-400 mb-1">
              <Award className="w-4 h-4 text-amber-400" />
              <span className="text-xs uppercase tracking-wider">Points</span>
            </div>
            <span className="text-xl font-bold">1,250</span>
          </div>
          <div className="glass rounded-xl p-3 border-white/5 flex flex-col items-center md:items-start">
            <div className="flex items-center gap-2 text-gray-400 mb-1">
              <Heart className="w-4 h-4 text-red-400" />
              <span className="text-xs uppercase tracking-wider">Wishlist</span>
            </div>
            <span className="text-xl font-bold">12</span>
          </div>
          <div className="glass rounded-xl p-3 border-white/5 flex flex-col items-center md:items-start">
            <div className="flex items-center gap-2 text-gray-400 mb-1">
              <MapPin className="w-4 h-4 text-blue-400" />
              <span className="text-xs uppercase tracking-wider">Addresses</span>
            </div>
            <span className="text-xl font-bold">3</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

const experts = [
  {
    name: 'Dr. Sarah Jenkins',
    role: 'Medical Advisor',
    specialty: 'Cannabinoid Therapy',
    image: 'bg-emerald-900',
    article: 'The Endocannabinoid System Explained'
  },
  {
    name: 'Marcus Chen',
    role: 'Master Grower',
    specialty: 'Genetics & Cultivation',
    image: 'bg-blue-900',
    article: 'Understanding Terpene Profiles'
  },
  {
    name: 'Elena Rodriguez',
    role: 'Wellness Coach',
    specialty: 'Holistic Integration',
    image: 'bg-purple-900',
    article: 'Mindful Consumption Practices'
  }
];

export function ExpertInsights() {
  return (
    <section className="py-24 relative bg-black/50 border-y border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-4xl font-bold mb-16 text-center">Expert Insights</h2>
        
        <div className="grid md:grid-cols-3 gap-8">
          {experts.map((expert, i) => (
            <motion.div
              key={expert.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="glass p-6 rounded-2xl flex flex-col items-center text-center group"
            >
              <div className={`w-24 h-24 rounded-full ${expert.image} border-2 border-white/10 mb-6 flex items-center justify-center overflow-hidden`}>
                {/* Abstract avatar */}
                <div className="w-full h-full bg-gradient-to-tr from-black/40 to-transparent" />
              </div>
              
              <h3 className="text-xl font-bold mb-1">{expert.name}</h3>
              <p className="text-primary text-sm font-medium mb-1">{expert.role}</p>
              <p className="text-gray-500 text-xs uppercase tracking-wider mb-8">{expert.specialty}</p>
              
              <div className="w-full bg-white/[0.02] border border-white/5 rounded-xl p-4 text-left group-hover:bg-white/5 transition-colors cursor-pointer">
                <span className="text-[10px] text-gray-500 uppercase tracking-wider block mb-1">Featured Article</span>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-white line-clamp-1">{expert.article}</span>
                  <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-primary transition-colors shrink-0" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

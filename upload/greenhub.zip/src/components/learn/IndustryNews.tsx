import { motion } from 'motion/react';

const news = [
  {
    category: 'Regulation',
    title: 'New State Guidelines for Lab Testing Standards',
    date: 'Oct 15, 2024',
    readTime: '4 min read'
  },
  {
    category: 'Research',
    title: 'Study Finds Minor Cannabinoids Effective for Sleep',
    date: 'Oct 12, 2024',
    readTime: '6 min read'
  },
  {
    category: 'Market Trends',
    title: 'The Rise of Solventless Extracts in 2024',
    date: 'Oct 08, 2024',
    readTime: '5 min read'
  },
  {
    category: 'Innovation',
    title: 'New Nano-Emulsion Technology Speeds Up Edible Onset',
    date: 'Oct 02, 2024',
    readTime: '7 min read'
  }
];

export function IndustryNews() {
  return (
    <section className="py-24 relative">
      <div className="max-w-4xl mx-auto px-6">
        <div className="flex justify-between items-end mb-12 border-b border-white/10 pb-6">
          <h2 className="text-4xl font-bold">Industry News</h2>
          <button className="text-primary hover:text-white transition-colors font-medium text-sm">
            View All News
          </button>
        </div>

        <div className="space-y-6">
          {news.map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass p-6 rounded-2xl flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-6 group cursor-pointer hover:bg-white/[0.05] transition-colors"
            >
              <div className="sm:w-32 shrink-0">
                <span className="text-xs font-bold text-primary uppercase tracking-wider">{item.category}</span>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold mb-2 group-hover:text-emerald-400 transition-colors">{item.title}</h3>
                <div className="flex items-center gap-3 text-xs text-gray-500">
                  <span>{item.date}</span>
                  <span className="w-1 h-1 rounded-full bg-gray-600" />
                  <span>{item.readTime}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { motion } from 'motion/react';
import { PlayCircle, Clock } from 'lucide-react';

const videos = [
  {
    title: 'Cannabis 101: The Absolute Basics',
    instructor: 'Dr. Sarah Jenkins',
    duration: '15:24',
    image: 'bg-gradient-to-tr from-emerald-900 to-teal-900',
    featured: true
  },
  {
    title: 'How Edibles Actually Work in the Body',
    instructor: 'Chef James',
    duration: '12:05',
    image: 'bg-gradient-to-tr from-pink-900 to-orange-900',
    featured: false
  },
  {
    title: 'Choosing the Perfect Strain for You',
    instructor: 'Marcus Chen',
    duration: '18:40',
    image: 'bg-gradient-to-tr from-purple-900 to-indigo-900',
    featured: false
  },
  {
    title: 'Understanding Terpenes & Aromas',
    instructor: 'Elena Rodriguez',
    duration: '22:15',
    image: 'bg-gradient-to-tr from-amber-900 to-red-900',
    featured: false
  }
];

export function VideoLearning() {
  return (
    <section className="py-24 relative bg-black/40 border-y border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-4xl font-bold mb-12">Video Masterclasses</h2>
        
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Featured Video */}
          <div className="lg:col-span-2">
            {videos.filter(v => v.featured).map(video => (
              <motion.div 
                key={video.title}
                initial={{ opacity: 0, scale: 0.98 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                className="relative rounded-[2rem] overflow-hidden group cursor-pointer h-full min-h-[400px] border border-white/10"
              >
                <div className={`absolute inset-0 ${video.image} opacity-80 mix-blend-luminosity group-hover:scale-105 transition-transform duration-700`} />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
                
                {/* Abstract play button overlay */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-20 h-20 rounded-full bg-black/40 backdrop-blur-md border border-white/20 flex items-center justify-center group-hover:bg-primary group-hover:text-black transition-all group-hover:scale-110">
                    <PlayCircle className="w-10 h-10" />
                  </div>
                </div>

                <div className="absolute bottom-0 left-0 right-0 p-8">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="px-3 py-1 bg-primary text-black rounded-full text-xs font-bold uppercase tracking-wider">Featured</span>
                    <div className="flex items-center gap-1 text-xs text-gray-300 font-medium bg-black/50 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                      <Clock className="w-3.5 h-3.5" />
                      {video.duration}
                    </div>
                  </div>
                  <h3 className="text-3xl font-bold text-white mb-2">{video.title}</h3>
                  <p className="text-gray-300 font-medium">with {video.instructor}</p>
                </div>
              </motion.div>
            ))}
          </div>
          
          {/* Smaller Videos */}
          <div className="flex flex-col gap-6">
            {videos.filter(v => !v.featured).map((video, i) => (
              <motion.div 
                key={video.title}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="relative rounded-2xl overflow-hidden group cursor-pointer flex-1 border border-white/10 min-h-[160px]"
              >
                <div className={`absolute inset-0 ${video.image} opacity-60 mix-blend-luminosity group-hover:scale-105 transition-transform duration-700`} />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-black/20" />
                
                <div className="absolute inset-0 p-5 flex flex-col justify-end">
                  <div className="flex items-center gap-2 mb-2">
                    <PlayCircle className="w-6 h-6 text-white/70 group-hover:text-primary transition-colors" />
                    <span className="text-xs text-gray-300 font-medium">{video.duration}</span>
                  </div>
                  <h4 className="font-bold text-white text-lg leading-tight mb-1 group-hover:text-primary transition-colors">{video.title}</h4>
                  <p className="text-xs text-gray-400">{video.instructor}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

import { motion } from 'motion/react';

const topics = [
  { name: 'Sleep Support', icon: '🌙', articles: 12 },
  { name: 'Stress Relief', icon: '🧘', articles: 18 },
  { name: 'Relaxation', icon: '🛁', articles: 24 },
  { name: 'Creativity', icon: '🎨', articles: 9 },
  { name: 'Focus', icon: '🎯', articles: 15 },
  { name: 'Recovery', icon: '❤️‍🩹', articles: 11 }
];

export function WellnessTopics() {
  return (
    <section className="py-24 relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Wellness & Lifestyle</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">Explore how cannabis can be integrated into your daily routine for specific wellness goals.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          {topics.map((topic, i) => (
            <motion.div
              key={topic.name}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass glass-hover rounded-2xl p-6 md:p-8 text-center group cursor-pointer"
            >
              <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300 inline-block">
                {topic.icon}
              </div>
              <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">{topic.name}</h3>
              <p className="text-sm text-gray-500">{topic.articles} Articles</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ProfileHeader } from '../components/profile/ProfileHeader';
import { ProfileSidebar } from '../components/profile/ProfileSidebar';
import { DashboardOverview } from '../components/profile/views/DashboardOverview';
import { OrdersView } from '../components/profile/views/OrdersView';
import { FavoritesView } from '../components/profile/views/FavoritesView';
import { RewardsView } from '../components/profile/views/RewardsView';
import { SettingsView } from '../components/profile/views/SettingsView';
import { LearningProgressView } from '../components/profile/views/LearningProgressView';
import { Menu, X } from 'lucide-react';

export type ProfileTab = 'dashboard' | 'orders' | 'favorites' | 'rewards' | 'subscriptions' | 'addresses' | 'payment' | 'learning' | 'reviews' | 'notifications' | 'security' | 'settings' | 'support';

export function Profile() {
  const [activeTab, setActiveTab] = useState<ProfileTab>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const renderView = () => {
    switch (activeTab) {
      case 'dashboard': return <DashboardOverview setActiveTab={setActiveTab} />;
      case 'orders': return <OrdersView />;
      case 'favorites': return <FavoritesView />;
      case 'rewards': return <RewardsView />;
      case 'learning': return <LearningProgressView />;
      case 'settings': return <SettingsView />;
      default: return (
        <div className="glass rounded-[2rem] p-12 text-center border border-white/10 flex flex-col items-center justify-center min-h-[400px]">
          <h2 className="text-2xl font-bold mb-4 capitalize">{activeTab}</h2>
          <p className="text-gray-400">This section is currently under construction.</p>
        </div>
      );
    }
  };

  return (
    <main className="pt-24 pb-12 min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        <ProfileHeader />

        {/* Mobile Navigation Toggle */}
        <div className="lg:hidden mb-6">
          <button 
            onClick={() => setIsMobileMenuOpen(true)}
            className="w-full flex items-center justify-between glass py-4 px-6 rounded-2xl border-white/10"
          >
            <span className="font-bold capitalize">{activeTab.replace('-', ' ')}</span>
            <Menu className="w-5 h-5 text-gray-400" />
          </button>
        </div>
        
        <div className="flex flex-col lg:flex-row gap-8 mt-8">
          {/* Desktop Sidebar */}
          <div className="hidden lg:block w-72 shrink-0">
            <ProfileSidebar activeTab={activeTab} setActiveTab={setActiveTab} />
          </div>

          {/* Main Content Area */}
          <div className="flex-1 min-w-0">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                {renderView()}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[80] lg:hidden"
            />
            <motion.div 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-y-0 left-0 w-[300px] bg-[#0a0a0a] border-r border-white/10 z-[90] lg:hidden overflow-y-auto"
            >
              <div className="p-6 border-b border-white/10 flex items-center justify-between sticky top-0 bg-[#0a0a0a] z-10">
                <h3 className="font-bold text-lg">Menu</h3>
                <button 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-4">
                <ProfileSidebar 
                  activeTab={activeTab} 
                  setActiveTab={(tab) => {
                    setActiveTab(tab);
                    setIsMobileMenuOpen(false);
                  }} 
                />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </main>
  );
}

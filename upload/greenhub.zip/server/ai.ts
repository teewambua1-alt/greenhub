import { GoogleGenAI } from "@google/genai";

let aiClient: GoogleGenAI | null = null;

export function getAIClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is required");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

export async function generateLearnAnswer(question: string): Promise<string | null> {
  const ai = getAIClient();
  
  const systemInstruction = `You are an expert cannabis educator and wellness advisor for GreenHub, a premium cannabis dispensary.
Your goal is to provide accurate, helpful, and educational answers to users' questions about cannabis, wellness, strains, consumption methods, and related topics.

GreenHub Domain Knowledge:
- THC (Tetrahydrocannabinol) is known for its psychoactive effects, but it also has potential benefits for sleep. It can help reduce the time it takes to fall asleep, though it may decrease REM sleep over time.
- For sleep specifically, Indica-dominant strains (like 'Granddaddy Purple' or 'Northern Lights') are often recommended to promote relaxation.
- Products with a balance of THC and CBD (like our 'CBD Sleep Drops') can be highly effective, as CBD helps reduce anxiety without the "high".
- Always emphasize the importance of "starting low and going slow", particularly with edibles.
- The GreenHub catalog includes premium products such as 'Blue Dream Reserve', 'Mango Haze V-Pen', 'Live Resin Cartridges', and 'Cherry Bomb Chocolates'.

Keep your answers informative, well-structured (use markdown), and easy to understand.
Maintain a professional, objective, and premium tone. Do not make medical claims. Always advise consulting a physician for medical advice.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.1-flash-lite',
    contents: question,
    config: {
      systemInstruction,
    }
  });

  return response.text || null;
}

export async function generateChatResponse(messages: any[]): Promise<string | null> {
  const ai = getAIClient();

  const contents = messages.map((msg: any) => ({
    role: msg.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: msg.text || "Here are some recommendations." }]
  }));

  const systemInstruction = `You are a helpful virtual budtender for GreenHub, a premium cannabis dispensary. 
Answer the user's questions based on the app. The app features:
- Premium cannabis products (Flower, Vapes, Edibles, Concentrates, CBD)
- A rewards program (points earned on every purchase, Gold/Platinum tiers)
- Educational content (Articles, Videos, Certificates)
- Order tracking and history
- Saved favorites and addresses

Provide concise, helpful, and friendly responses. Maintain a luxury, professional, yet approachable tone.
If the user asks for recommendations, you can suggest some products and describe them.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.1-flash-lite',
    contents,
    config: {
      systemInstruction,
    }
  });

  return response.text || null;
}

export async function generateRecommendations(mood: string, intent: string): Promise<any | null> {
  const ai = getAIClient();

  const prompt = `You are a helpful budtender at a premium cannabis dispensary.
A customer is looking for a product recommendation.
Their mood/state: ${mood || "Not specified"}
Their intent/goal: ${intent || "Not specified"}

Please provide 3 product recommendations that fit this profile.
Format the output as a JSON array of objects, with each object having the following keys:
- "name": Product name (e.g., "Blue Dream", "Lavender Sleep Tincture")
- "category": (e.g., "Flower", "Edible", "Vape", "Tincture")
- "description": A brief 1-2 sentence description explaining why it's a good fit.
- "thc_level": Approximate THC percentage or mg.
- "cbd_level": Approximate CBD percentage or mg.

Output ONLY valid JSON.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.1-flash-lite',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
    }
  });

  if (response.text) {
    return JSON.parse(response.text);
  }
  return null;
}

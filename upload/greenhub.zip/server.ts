import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import 'dotenv/config';
import { generateChatResponse, generateLearnAnswer, generateRecommendations } from "./server/ai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Chat API route
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages } = req.body;
      
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "Messages array is required" });
      }

      const text = await generateChatResponse(messages);
      
      if (text) {
        res.json({ text });
      } else {
        res.status(500).json({ error: "No response from Gemini API" });
      }

    } catch (error) {
      console.error("Error in chat:", error);
      res.status(500).json({ error: "Failed to generate response" });
    }
  });

  // Learn API route
  app.post("/api/learn", async (req, res) => {
    try {
      const { question } = req.body;
      
      if (!question) {
        return res.status(400).json({ error: "Question is required" });
      }

      const text = await generateLearnAnswer(question);
      
      if (text) {
        res.json({ text });
      } else {
        res.status(500).json({ error: "No response from Gemini API" });
      }

    } catch (error) {
      console.error("Error in learn chat:", error);
      res.status(500).json({ error: "Failed to generate educational response" });
    }
  });

  // API routes
  app.post("/api/recommend", async (req, res) => {
    try {
      const { mood, intent } = req.body;
      
      const recommendations = await generateRecommendations(mood, intent);
      
      if (recommendations) {
        res.json({ recommendations });
      } else {
        res.status(500).json({ error: "No response from Gemini API" });
      }

    } catch (error) {
      console.error("Error generating recommendations:", error);
      res.status(500).json({ error: "Failed to generate recommendations" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
